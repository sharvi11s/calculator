
<?php

session_start();

// Clear all session data
$_SESSION = [];

// Destroy the session
session_destroy();

// Redirect to login page
header("Location: ../html/login.html");
exit;

?>
